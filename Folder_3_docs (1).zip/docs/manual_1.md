// Placeholder for docs/manual_1.md
