// Placeholder for docs/manual_3.md
