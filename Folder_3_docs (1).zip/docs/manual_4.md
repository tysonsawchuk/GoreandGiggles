// Placeholder for docs/manual_4.md
