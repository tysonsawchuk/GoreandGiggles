# doc_3.md

This is a placeholder for doc_3.md.
