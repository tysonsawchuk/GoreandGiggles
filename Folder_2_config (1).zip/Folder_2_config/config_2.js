// Configuration file 2
const config2 = { setting: true };