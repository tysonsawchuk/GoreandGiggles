// Configuration file 3
const config3 = { setting: true };