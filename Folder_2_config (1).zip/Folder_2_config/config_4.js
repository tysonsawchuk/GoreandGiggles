// Configuration file 4
const config4 = { setting: true };