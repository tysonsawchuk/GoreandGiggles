// Configuration file 1
const config1 = { setting: true };