// Configuration file 5
const config5 = { setting: true };