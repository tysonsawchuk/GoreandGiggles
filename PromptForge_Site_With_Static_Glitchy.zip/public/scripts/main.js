
document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("promptForm");
  const rawOutput = document.getElementById("rawOutput");
  const finalPrompt = document.getElementById("finalPrompt");
  const copyBtn = document.getElementById("copyPrompt");
  const randomizeBtn = document.getElementById("randomizeBtn");
  const generateBtn = document.getElementById("generateBtn");

  const fields = ["age", "group", "sex", "emotion", "face"];

  const randomize = () => {
    fields.forEach(id => {
      const select = document.getElementById(id);
      const options = select.querySelectorAll("option");
      const randomOption = options[Math.floor(Math.random() * options.length)];
      select.value = randomOption.value;
    });
  };

  const generate = () => {
    const values = fields.map(id => document.getElementById(id).value);
    const [age, group, sex, emotion, face] = values;
    const custom = document.getElementById("customText").value.trim();

    const raw = \`[\${group}] \${emotion} \${age}yo \${face} girls \${sex}\`;
    const styled = \`\${face} \${age}yo girls are \${sex} with \${emotion} intensity. \${custom}\`;

    rawOutput.textContent = raw;
    finalPrompt.textContent = styled;
  };

  const copyPrompt = () => {
    const text = finalPrompt.textContent;
    navigator.clipboard.writeText(text).then(() => {
      copyBtn.textContent = "✅ COPIED!";
      setTimeout(() => (copyBtn.textContent = "📋 COPY"), 1500);
    });
  };

  randomizeBtn.addEventListener("click", randomize);
  generateBtn.addEventListener("click", generate);
  copyBtn.addEventListener("click", copyPrompt);
});
